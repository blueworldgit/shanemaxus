<?php

function mobex_enovathemes_child_scripts() {
    wp_enqueue_style( 'mobex_enovathemes-parent-style', get_template_directory_uri(). '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'mobex_enovathemes_child_scripts' );

add_action('after_switch_theme', 'mobex_child_repair_theme_mods_and_kirki_css');
add_action('admin_init', 'mobex_child_repair_theme_mods_and_kirki_css_once');

function mobex_child_repair_theme_mods_and_kirki_css_once() {
    // If we already repaired, skip.
    if (get_option('mobex_child_theme_mods_repaired')) {
        return;
    }
    $did = mobex_child_repair_theme_mods_and_kirki_css();
    if ($did) {
        update_option('mobex_child_theme_mods_repaired', 1);
    }
}

/**
 * Returns true if it actually migrated/changed anything.
 */
function mobex_child_repair_theme_mods_and_kirki_css() {
    $parent = get_template();
    $child  = get_stylesheet();
    if ($parent === $child) {
        // Not a child setup.
        return false;
    }

    $parent_option = 'theme_mods_' . $parent;
    $child_option  = 'theme_mods_' . $child;

    $parent_mods = get_option($parent_option, []);
    $child_mods  = get_option($child_option, null); // null helps us know if it doesn't exist at all

    // Nothing to copy from
    if (empty($parent_mods) || !is_array($parent_mods)) {
        // Still clear Kirki cache to be safe
        mobex_child_clear_kirki_css_cache();
        return false;
    }

    // Remove cross-theme CSS post link if present
    unset($parent_mods['custom_css_post_id']);

    // Decide if child mods are effectively "empty" or only defaults
    $needs_migration = false;

    if ($child_mods === null) {
        // Child option doesn't exist yet — definitely migrate.
        $needs_migration = true;
        $child_mods = [];
    } else {
        // If it exists, check if it's empty or only holds benign defaults.
        if (!is_array($child_mods) || empty($child_mods)) {
            $needs_migration = true;
            $child_mods = (array) $child_mods;
        } else {
            // Keys that WP often seeds which don't represent actual Customizer design choices
            $benign_keys = [
                'nav_menu_locations',
                'sidebars_widgets',
                'widget_*', // pattern-like
                'custom_css_post_id',
            ];

            $child_keys = array_keys($child_mods);
            $non_benign_found = false;

            foreach ($child_keys as $k) {
                if ($k === 'custom_css_post_id') {
                    continue;
                }
                // Treat widget_* as benign
                $is_benign = in_array($k, ['nav_menu_locations','sidebars_widgets'], true) || str_starts_with($k, 'widget_');
                if (!$is_benign && !empty($child_mods[$k])) {
                    $non_benign_found = true;
                    break;
                }
            }
            if (!$non_benign_found) {
                $needs_migration = true;
            }
        }
    }

    // If migration is needed, MERGE: child's values win (if any), else parent fills in.
    if ($needs_migration) {
        $merged = array_replace($parent_mods, $child_mods); // child overrides parent if both have a key
        update_option($child_option, $merged);

        // Clear Kirki caches so CSS regenerates for the CHILD right away
        mobex_child_clear_kirki_css_cache();

        // Also bump the theme mods revision to force refresh in some setups
        if (function_exists('wp_set_custom_css_post')) {
            // do nothing here; just noting you can also touch the custom CSS if you use it
        }

        return true;
    }

    // Even if no migration, nuking Kirki cache can still fix "looks active in Customizer but not on FE"
    mobex_child_clear_kirki_css_cache();
    return false;
}

/**
 * Clear Kirki dynamic CSS caches (transients + generated files).
 * Safe to run even if Kirki isn't present.
 */
function mobex_child_clear_kirki_css_cache() {
    global $wpdb;

    // Delete Kirki transients
    $wpdb->query("
        DELETE FROM {$wpdb->options}
        WHERE option_name LIKE '_transient_kirki_%'
           OR option_name LIKE '_transient_timeout_kirki_%'
    ");

    // Remove generated CSS files in uploads/kirki
    $upload_dir = wp_get_upload_dir();
    if (!empty($upload_dir['basedir'])) {
        $kirki_dir = trailingslashit($upload_dir['basedir']) . 'kirki';
        if (is_dir($kirki_dir)) {
            foreach (glob($kirki_dir . '/*') as $file) {
                if (is_file($file) && is_writable($file)) {
                    @unlink($file);
                }
            }
        }
    }

    // If Kirki's CSS generator class is available, try to force a rebuild.
    // (This is optional; many installs auto-regenerate on next page load.)
    if (class_exists('\Kirki\Compatibility\CSS') && method_exists('\Kirki\Compatibility\CSS', 'gather_styles')) {
        try {
            \Kirki\Compatibility\CSS::gather_styles(true); // true => force
        } catch (\Throwable $e) {
            // Silently ignore; regeneration will happen on next request.
        }
    }
}

/**
 * PHP 8.0-safe polyfill for str_starts_with for older WP envs.
 */
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) {
        return $needle !== '' && strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}


?>